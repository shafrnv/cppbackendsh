#pragma once
#ifdef WIN32
#include <sdkddkver.h>
#endif
